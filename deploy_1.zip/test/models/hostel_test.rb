require "test_helper"

class HostelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
