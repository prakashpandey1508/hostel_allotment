require "test_helper"

class CollegeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
