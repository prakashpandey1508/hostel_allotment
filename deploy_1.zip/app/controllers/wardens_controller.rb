class WardensController < ApplicationController
  def index
  end

  def show
  end

  def edit
  end

  def new
  end
end
