class College < ApplicationRecord
end
