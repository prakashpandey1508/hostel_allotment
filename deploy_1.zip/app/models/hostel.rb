class Hostel < ApplicationRecord
    has_many :students
end
