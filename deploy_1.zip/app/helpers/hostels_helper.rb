module HostelsHelper
end
